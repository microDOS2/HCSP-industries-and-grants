import json, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
results = {}

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for width in (1680, 1280):
        for p in ("index.html", "competitors.html", "funding.html"):
            ctx = browser.new_context(viewport={"width": width, "height": 1000})
            page = ctx.new_page()
            errs = []
            page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
            for i in range(3):
                try:
                    page.goto(BASE + p, wait_until="commit", timeout=45000)
                    page.wait_for_load_state("load", timeout=60000)
                    break
                except Exception:
                    time.sleep(3)
            page.wait_for_timeout(4000)
            # scroll through the whole page to trigger all lazy content
            page.evaluate("""async () => {
              const h = document.body.scrollHeight;
              for (let y = 0; y <= h; y += 600) {
                window.scrollTo(0, y);
                await new Promise(r => setTimeout(r, 120));
              }
              window.scrollTo(0, 0);
            }""")
            page.wait_for_timeout(3000)
            ov = page.evaluate("""() => {
              const de = document.documentElement;
              // find any elements sticking out past the viewport width
              const vw = de.clientWidth;
              const offenders = [];
              document.querySelectorAll('*').forEach(el => {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && (r.right > vw + 1 || r.left < -1)) {
                  const cs = getComputedStyle(el);
                  if (cs.position === 'fixed' && el.id !== 'dash-rail') { /* still counts */ }
                  offenders.push(el.tagName + (el.id ? '#' + el.id : '') + '.' + String(el.className).slice(0,40)
                                 + ' L' + Math.round(r.left) + ' R' + Math.round(r.right));
                }
              });
              return {scrollW: de.scrollWidth, clientW: de.clientWidth,
                      bodyScrollW: document.body.scrollWidth,
                      offenders: offenders.slice(0, 12), nOffenders: offenders.length};
            }""")
            results[f"{width}_{p}"] = {"overflow": ov, "errors": errs}
            page.screenshot(path=f"{OUT}/final_{width}_{p.replace('.html','')}.png")
            page.close(); ctx.close()
    browser.close()

with open(f"{OUT}/final_scan.json", "w") as f:
    json.dump(results, f, indent=2)
for k, v in results.items():
    o = v["overflow"]
    print(k, "| scrollW", o["scrollW"], "clientW", o["clientW"], "| overflow:", o["scrollW"] - o["clientW"],
          "| offenders:", o["nOffenders"], "| errors:", v["errors"])
    for of in o["offenders"][:5]:
        print("   ", of)
