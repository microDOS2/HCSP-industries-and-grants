import json, os, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
results = {}

OVERLAP_JS = """() => {
  const labs = [...document.querySelectorAll('#comp3d .c3d-label')]
    .filter(el => el.style.display !== 'none' && el.offsetParent !== null);
  const rects = labs.map(el => {
    const r = el.getBoundingClientRect();
    return {text: el.textContent, x: r.x, y: r.y, w: r.width, h: r.height};
  });
  const overlaps = [];
  for (let i = 0; i < rects.length; i++) {
    for (let j = i + 1; j < rects.length; j++) {
      const a = rects[i], b = rects[j];
      const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
      const oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      if (ox > 2 && oy > 2) {
        overlaps.push({a: a.text, b: b.text, ox: +ox.toFixed(1), oy: +oy.toFixed(1),
                       areaPct: +(100*ox*oy/Math.min(a.w*a.h, b.w*b.h)).toFixed(1)});
      }
    }
  }
  return {nLabels: rects.length, nOverlaps: overlaps.length, overlaps: overlaps.slice(0, 10)};
}"""

def load(page, path, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            return
        except Exception as e:
            last = e; time.sleep(3)
    raise last

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for width in (1680, 1280):
        ctx = browser.new_context(viewport={"width": width, "height": 1000})
        page = ctx.new_page()
        errs = []
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
        load(page, "competitors.html")
        page.wait_for_selector("#comp3d .c3d-tabs", timeout=60000)
        page.eval_on_selector("#comp3d", "el => el.scrollIntoView({block:'center'})")
        page.wait_for_timeout(2000)
        res = {}
        for view in ("panels", "timeline"):
            page.evaluate(f"() => document.querySelector('#comp3d [data-v=\"{view}\"]').click()")
            page.wait_for_timeout(1000)
            if view == "timeline":
                res["timeline_3d_toggle"] = page.evaluate("""() => {
                  const b = document.querySelector('#comp3d [data-ctl="view3d"]');
                  if (b && !b.hidden) { b.click(); return 'clicked'; }
                  return 'unavailable';
                }""")
                page.wait_for_timeout(1500)
            # pause auto-orbit for deterministic sampling
            page.evaluate("""() => {
              const b = document.querySelector('#comp3d [data-ctl="pause"]');
              if (b && b.getAttribute('aria-pressed') !== 'true') b.click();
            }""")
            page.wait_for_timeout(500)
            canvas = page.locator("#comp3d canvas.c3d-stage")
            box = canvas.bounding_box()
            cx, cy = box["x"] + box["width"]/2, box["y"] + box["height"]/2
            samples = []
            for s in range(6):
                if s > 0:
                    # drag ~60 degrees each step (OrbitControls: full width drag ≈ 360deg)
                    page.mouse.move(cx, cy)
                    page.mouse.down()
                    page.mouse.move(cx + box["width"]/6, cy, steps=8)
                    page.mouse.up()
                    page.wait_for_timeout(900)
                ov = page.evaluate(OVERLAP_JS)
                samples.append(ov)
                try:
                    page.screenshot(path=f"{OUT}/d3_{width}_{view}_s{s}.png", timeout=15000)
                except Exception as e:
                    samples[-1]["screenshotError"] = str(e)[:100]
            res[view] = samples
            # unpause for cleanliness
            page.evaluate("""() => {
              const b = document.querySelector('#comp3d [data-ctl="pause"]');
              if (b && b.getAttribute('aria-pressed') === 'true') b.click();
            }""")
        results[width] = {"views": res, "errors": errs}
        page.close(); ctx.close()
    browser.close()

with open(f"{OUT}/d3_results.json", "w") as f:
    json.dump(results, f, indent=2)
for w, r in results.items():
    print('WIDTH', w, 'errors:', r['errors'])
    for view, samples in r['views'].items():
        if not isinstance(samples, list):
            print(' ', view, samples); continue
        for si, s in enumerate(samples):
            print(f'  {view} s{si}: labels={s["nLabels"]} overlaps={s["nOverlaps"]}', s['overlaps'][:3])
