import json, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
results = {}

def load(page, path, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            return
        except Exception as e:
            last = e; time.sleep(3)
    raise last

TABLE_JS = """(tid) => {
  const t = document.getElementById(tid);
  const wrap = t.closest('.table-scroll');
  const wr = wrap.getBoundingClientRect();
  const rows = t.tBodies[0] ? t.tBodies[0].rows.length : 0;
  const rail = document.getElementById('dash-rail');
  const railR = rail ? rail.getBoundingClientRect() : null;
  // column headers + rightmost cell extent
  const head = [...t.tHead.rows[0].cells].map(th => th.textContent.trim());
  let maxRight = 0;
  [...t.tBodies[0].rows].forEach(tr => { const r = tr.getBoundingClientRect(); if (r.right > maxRight) maxRight = r.right; });
  const tr0 = t.getBoundingClientRect();
  return {
    rows,
    cols: head,
    tableRect: {left: +tr0.left.toFixed(1), right: +tr0.right.toFixed(1), width: +tr0.width.toFixed(1)},
    wrapRect: {left: +wr.left.toFixed(1), right: +wr.right.toFixed(1)},
    wrapScrollW: wrap.scrollWidth, wrapClientW: wrap.clientWidth,
    wrapScrollH: wrap.scrollHeight, wrapClientH: wrap.clientHeight,
    wrapHScrollable: wrap.scrollWidth > wrap.clientWidth + 1,
    wrapVScrollable: wrap.scrollHeight > wrap.clientHeight + 1,
    railLeft: railR ? railR.left : null,
    docOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth
  };
}"""

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for width in (1680, 1280):
        ctx = browser.new_context(viewport={"width": width, "height": 1000})
        page = ctx.new_page()
        errs = []
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
        load(page, "funding.html")
        page.wait_for_selector("#grant-table tbody tr", timeout=60000)
        page.wait_for_timeout(2500)
        r = {}
        for tid in ("grant-table", "top15-table"):
            page.eval_on_selector(f"#{tid}", "el => el.scrollIntoView({block:'center'})")
            page.wait_for_timeout(800)
            info = page.evaluate(TABLE_JS, tid)
            # vertical reachability: scroll wrap to bottom, check last row visible in wrap viewport
            reach = page.evaluate("""(tid) => {
              const t = document.getElementById(tid);
              const wrap = t.closest('.table-scroll');
              wrap.scrollTop = wrap.scrollHeight;
              const last = t.tBodies[0].rows[t.tBodies[0].rows.length - 1];
              const lr = last.getBoundingClientRect();
              const wr = wrap.getBoundingClientRect();
              const visible = lr.top < wr.bottom && lr.bottom > wr.top;
              const txt = last.textContent.replace(/\\s+/g,' ').trim().slice(0, 60);
              wrap.scrollTop = 0;
              // horizontal reachability of last column
              let hReach = null;
              if (wrap.scrollWidth > wrap.clientWidth + 1) {
                wrap.scrollLeft = wrap.scrollWidth;
                const hc = t.tHead.rows[0].cells[t.tHead.rows[0].cells.length-1];
                const hr = hc.getBoundingClientRect();
                hReach = {lastColHeader: hc.textContent.trim(), headerRight: +hr.right.toFixed(1),
                          wrapRight: +wr.right.toFixed(1), reachable: hr.right <= wr.right + 1};
                wrap.scrollLeft = 0;
              }
              return {lastRowVisibleAtBottom: visible, lastRowText: txt, horizontal: hReach};
            }""", tid)
            # rail coverage: is any part of the table's rows under the rail?
            cover = page.evaluate("""(tid) => {
              const rail = document.getElementById('dash-rail');
              if (!rail) return {rail: null};
              const rr = rail.getBoundingClientRect();
              const t = document.getElementById(tid);
              const wrap = t.closest('.table-scroll');
              const wr = wrap.getBoundingClientRect();
              return {railLeft: rr.left, wrapRight: +wr.right.toFixed(1),
                      wrapUnderRail: wr.right > rr.left + 1,
                      railPosition: getComputedStyle(rail).position};
            }""", tid)
            page.screenshot(path=f"{OUT}/d4_{width}_{tid}.png")
            r[tid] = {"info": info, "reachability": reach, "rail": cover}
        results[width] = {"tables": r, "errors": errs}
        page.close(); ctx.close()
    browser.close()

with open(f"{OUT}/d4_results.json", "w") as f:
    json.dump(results, f, indent=2)
print(json.dumps(results, indent=2))
