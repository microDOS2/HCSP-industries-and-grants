import json, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    ctx = browser.new_context(viewport={"width": 1680, "height": 1000})
    page = ctx.new_page()
    for i in range(3):
        try:
            page.goto(BASE + "funding.html", wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            break
        except Exception:
            time.sleep(3)
    page.wait_for_selector("#grant-table tbody tr", timeout=60000)
    out = page.evaluate("""() => {
      const g = document.getElementById('grant-table');
      const cell = g.tBodies[0].rows[0].cells[1];   // Program column
      const t15 = document.getElementById('top15-table');
      const cell15 = t15.tBodies[0].rows[0].cells[1];
      return {
        grantProgramCellHTML: cell.innerHTML,
        grantProgramCellText: cell.textContent.replace(/\\s+/g,' ').trim(),
        top15ProgramCellHTML: cell15.innerHTML,
        top15ProgramCellText: cell15.textContent.replace(/\\s+/g,' ').trim()
      };
    }""")
    print(json.dumps(out, indent=2))
    browser.close()
