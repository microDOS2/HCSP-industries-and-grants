import time, json
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"

def load(page, path, sel=None, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            if sel:
                page.wait_for_selector(sel, state="attached", timeout=45000)
            return True
        except Exception as e:
            last = e
            time.sleep(3)
    raise last

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    ctx = browser.new_context(viewport={"width": 1280, "height": 1000})
    page = ctx.new_page()
    load(page, "competitors.html", "body")
    page.wait_for_load_state("load", timeout=60000)
    page.wait_for_timeout(8000)
    out = page.evaluate("""() => ({
      readyState: document.readyState,
      tables: [...document.querySelectorAll('table')].map(t => ({
        id: t.id, hidden: t.closest('.table-scroll') ? t.closest('.table-scroll').hidden : null,
        head: t.tHead ? [...t.tHead.rows[0].cells].map(c=>c.textContent.trim()).slice(0,8) : []
      })),
      vc: !!document.getElementById('vendor-chart'),
      vcKids: document.getElementById('vendor-chart') ? document.getElementById('vendor-chart').children.length : -1
    })""")
    print(json.dumps(out, indent=2))
    browser.close()
