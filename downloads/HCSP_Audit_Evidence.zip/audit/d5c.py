import json, time, os
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
DL = f"{OUT}/downloads"

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    ctx = browser.new_context(viewport={"width": 1680, "height": 1000}, accept_downloads=True)
    page = ctx.new_page()
    errs = []
    page.on("console", lambda m: errs.append((m.type, m.text)))
    page.on("pageerror", lambda e: errs.append(("pageerror", str(e))))
    for i in range(3):
        try:
            page.goto(BASE + "index.html", wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            break
        except Exception as e:
            time.sleep(3)
    page.wait_for_timeout(5000)
    info = page.evaluate("""() => {
      const b = document.querySelectorAll('button.te-csv')[10];
      const wrap = b.closest('.table-scroll');
      const t = wrap ? wrap.querySelector('table') : null;
      return {
        section: b.closest('[id]') ? b.closest('[id]').id : null,
        visible: !!(b.offsetWidth || b.offsetHeight),
        display: getComputedStyle(b).display,
        parentDisplay: getComputedStyle(b.parentElement).display,
        wrapHidden: wrap ? wrap.hidden : null,
        tableId: t ? t.id : null,
        tableDisplay: t ? getComputedStyle(t).display : null,
        theadRows: t && t.tHead ? t.tHead.rows.length : null,
        tbodyRows: t && t.tBodies.length ? t.tBodies[0].rows.length : null,
        theadCells: t && t.tHead && t.tHead.rows.length ? t.tHead.rows[0].cells.length : null
      };
    }""")
    print(json.dumps(info, indent=2))
    try:
        with page.expect_download(timeout=20000) as di:
            page.evaluate("() => document.querySelectorAll('button.te-csv')[10].click()")
        d = di.value
        p = f"{DL}/index2__10_{d.suggested_filename}"
        d.save_as(p)
        print("OK", d.suggested_filename, os.path.getsize(p))
    except Exception as e:
        print("FAIL", str(e)[:200])
    print("console:", errs[-5:])
    browser.close()
