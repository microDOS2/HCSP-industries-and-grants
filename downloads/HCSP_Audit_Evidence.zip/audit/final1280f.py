import json, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    ctx = browser.new_context(viewport={"width": 1280, "height": 1000})
    page = ctx.new_page()
    errs = []
    page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
    for i in range(3):
        try:
            page.goto(BASE + "funding.html", wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            break
        except Exception:
            time.sleep(3)
    page.wait_for_timeout(4000)
    page.evaluate("""async () => {
      const h = document.body.scrollHeight;
      for (let y = 0; y <= h; y += 600) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 100)); }
      window.scrollTo(0, 0);
    }""")
    page.wait_for_timeout(2500)
    ov = page.evaluate("""() => {
      const de = document.documentElement;
      const vw = de.clientWidth;
      const offenders = [];
      document.querySelectorAll('*').forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && (r.right > vw + 1 || r.left < -1))
          offenders.push(el.tagName + (el.id ? '#' + el.id : '') + ' L' + Math.round(r.left) + ' R' + Math.round(r.right));
      });
      return {scrollW: de.scrollWidth, clientW: de.clientWidth, offenders: offenders.slice(0,12), nOffenders: offenders.length};
    }""")
    page.screenshot(path=f"{OUT}/final_1280_funding.png")
    print(json.dumps({"overflow": ov, "errors": errs}, indent=2))
    browser.close()
