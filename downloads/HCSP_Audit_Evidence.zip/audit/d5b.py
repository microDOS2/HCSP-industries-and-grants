import json, time, os
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
DL = f"{OUT}/downloads"
os.makedirs(DL, exist_ok=True)

def load(page, path, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            return
        except Exception as e:
            last = e; time.sleep(3)
    raise last

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    ctx = browser.new_context(viewport={"width": 1680, "height": 1000}, accept_downloads=True)
    page = ctx.new_page()
    errs = []
    page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
    load(page, "index.html")
    page.wait_for_timeout(5000)
    n = page.evaluate("() => document.querySelectorAll('button.te-csv').length")
    print("csv buttons:", n)
    out = []
    for i in range(n):
        meta = page.evaluate("""(i) => {
          const b = document.querySelectorAll('button.te-csv')[i];
          const sec = b.closest('[id]');
          return {i, section: sec ? sec.id : null};
        }""", i)
        try:
            with page.expect_download(timeout=15000) as di:
                page.evaluate("(i) => document.querySelectorAll('button.te-csv')[i].click()", i)
            d = di.value
            fname = d.suggested_filename
            path = f"{DL}/index2__{i:02d}_{fname}"
            d.save_as(path)
            out.append({**meta, "filename": fname, "size": os.path.getsize(path)})
            print(i, fname, os.path.getsize(path))
        except Exception as e:
            out.append({**meta, "error": str(e)[:150]})
            print(i, "ERROR", str(e)[:150])
    print("console errors:", errs)
    with open(f"{OUT}/d5_index_retry.json", "w") as f:
        json.dump({"downloads": out, "errors": errs}, f, indent=2)
    browser.close()
