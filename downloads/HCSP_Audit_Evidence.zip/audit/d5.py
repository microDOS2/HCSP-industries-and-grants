import json, time, os
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
DL = f"{OUT}/downloads"
os.makedirs(DL, exist_ok=True)
results = {}

def load(page, path, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            return
        except Exception as e:
            last = e; time.sleep(3)
    raise last

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for p in ("index.html", "competitors.html", "funding.html"):
        ctx = browser.new_context(viewport={"width": 1680, "height": 1000}, accept_downloads=True)
        page = ctx.new_page()
        errs = []
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
        load(page, p)
        page.wait_for_timeout(4000)
        if p == "competitors.html":
            # reveal vendor-table so its CSV button is live
            page.evaluate("""() => {
              const host = document.getElementById('vendor-chart');
              const b = [...host.querySelectorAll('button')].find(x => /^table$/i.test(x.textContent.trim()));
              if (b) b.click();
            }""")
            page.wait_for_timeout(800)
        # enumerate csv buttons and their tables
        btns = page.evaluate("""() => [...document.querySelectorAll('button.te-csv')].map((b, i) => {
          const tbl = b.closest('.table-scroll') ? b.closest('.table-scroll').querySelector('table')
                    : (b.parentElement && b.parentElement.nextElementSibling && b.parentElement.nextElementSibling.querySelector('table'));
          const t2 = b.closest('div').parentElement.querySelector('table');
          const t = tbl || t2;
          return {i,
                  visible: !!(b.offsetWidth || b.offsetHeight),
                  tableId: t ? t.id : null,
                  caption: t && t.querySelector('caption') ? t.querySelector('caption').textContent.slice(0,60) : null,
                  head: t && t.tHead ? [...t.tHead.rows[0].cells].map(c=>c.textContent.trim()).slice(0,4) : null};
        })""")
        downloads = []
        for meta in btns:
            if not meta["visible"]:
                downloads.append({**meta, "skipped": "button hidden"})
                continue
            # click the i-th visible button via locator
            loc = page.locator("button.te-csv").nth(btns.index(meta))
            try:
                loc.scroll_into_view_if_needed(timeout=10000)
                with page.expect_download(timeout=15000) as di:
                    loc.click()
                d = di.value
                fname = d.suggested_filename
                path = f"{DL}/{p.replace('.html','')}__{fname}"
                d.save_as(path)
                downloads.append({**meta, "filename": fname, "saved": path,
                                  "size": os.path.getsize(path)})
            except Exception as e:
                downloads.append({**meta, "error": str(e)[:200]})
        results[p] = {"buttons": btns, "downloads": downloads, "errors": errs}
        page.close(); ctx.close()
    browser.close()

with open(f"{OUT}/d5_results.json", "w") as f:
    json.dump(results, f, indent=2)
for p, r in results.items():
    print("PAGE", p, "errors:", r["errors"])
    for d in r["downloads"]:
        print("  ", d.get("filename"), "| table:", d.get("tableId"), "| head:", d.get("head"), "| size:", d.get("size"), d.get("error", d.get("skipped", "")))
