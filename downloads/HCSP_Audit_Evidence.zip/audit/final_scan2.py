import json, time, os
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
RES = f"{OUT}/final_scan.json"
results = json.load(open(RES)) if os.path.exists(RES) else {}

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for width in (1680, 1280):
        for p in ("index.html", "competitors.html", "funding.html"):
            key = f"{width}_{p}"
            if key in results:
                continue
            ctx = browser.new_context(viewport={"width": width, "height": 1000})
            page = ctx.new_page()
            errs = []
            page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
            for i in range(3):
                try:
                    page.goto(BASE + p, wait_until="commit", timeout=45000)
                    page.wait_for_load_state("load", timeout=60000)
                    break
                except Exception:
                    time.sleep(3)
            page.wait_for_timeout(3500)
            page.evaluate("""async () => {
              const h = document.body.scrollHeight;
              for (let y = 0; y <= h; y += 600) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 100)); }
              window.scrollTo(0, 0);
            }""")
            page.wait_for_timeout(2000)
            ov = page.evaluate("""() => {
              const de = document.documentElement;
              return {scrollW: de.scrollWidth, clientW: de.clientWidth,
                      bodyScrollW: document.body.scrollWidth,
                      overflow: de.scrollWidth - de.clientWidth};
            }""")
            results[key] = {"overflow": ov, "errors": errs}
            json.dump(results, open(RES, "w"), indent=2)
            print(key, ov, "errors:", errs, flush=True)
            page.close(); ctx.close()
    browser.close()
print("DONE")
