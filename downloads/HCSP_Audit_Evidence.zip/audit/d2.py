import json, os, time
from playwright.sync_api import sync_playwright

BASE = "https://microdos2.github.io/HCSP-industries-and-grants/"
OUT = "/mnt/agents/output/audit"
results = {}

def load(page, path, tries=3):
    last = None
    for i in range(tries):
        try:
            page.goto(BASE + path, wait_until="commit", timeout=45000)
            page.wait_for_load_state("load", timeout=60000)
            return
        except Exception as e:
            last = e; time.sleep(3)
    raise last

with sync_playwright() as pw:
    browser = pw.chromium.launch(args=["--enable-unsafe-swiftshader"])
    for width in (1280, 1680):
        ctx = browser.new_context(viewport={"width": width, "height": 1000})
        page = ctx.new_page()
        errs = []
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        page.on("pageerror", lambda e: errs.append("PAGEERROR: " + str(e)))
        load(page, "competitors.html")
        page.wait_for_selector("#vendor-table", state="attached", timeout=60000)
        page.eval_on_selector("#vendor-chart", "el => el.scrollIntoView({block:'center'})")
        page.wait_for_timeout(1500)
        clicked = page.evaluate("""() => {
          const host = document.getElementById('vendor-chart');
          const btns = [...host.querySelectorAll('button')];
          const b = btns.find(x => /^table$/i.test(x.textContent.trim()));
          if (b) { b.click(); return b.textContent.trim(); }
          return btns.map(x=>x.textContent.trim());
        }""")
        page.wait_for_timeout(1200)
        info = page.evaluate("""() => {
          const t = document.getElementById('vendor-table');
          const wrap = t.closest('.table-scroll');
          const head = [...t.tHead.rows[0].cells].map(th => th.textContent.trim());
          const lastIdx = head.length - 1;
          const hc = t.tHead.rows[0].cells[lastIdx];
          const hr = hc.getBoundingClientRect();
          const rail = document.getElementById('dash-rail');
          const railR = rail ? rail.getBoundingClientRect() : null;
          const wr = wrap.getBoundingClientRect();
          const cellRects = [...t.tBodies[0].rows].map(tr => {
            const c = tr.cells[lastIdx]; const r = c.getBoundingClientRect();
            return {left: +r.left.toFixed(1), right: +r.right.toFixed(1)};
          });
          const covered = railR ? cellRects.filter(cr => cr.right > railR.left + 1).length : 0;
          return {
            cols: head, hidden: wrap.hidden,
            sourcesHeaderRect: {left: +hr.left.toFixed(1), right: +hr.right.toFixed(1)},
            wrapRect: {left: +wr.left.toFixed(1), right: +wr.right.toFixed(1),
                       scrollW: wrap.scrollWidth, clientW: wrap.clientWidth},
            railRect: railR ? {left: railR.left, right: railR.right} : null,
            cellRects, cellsCoveredByRail: covered,
            viewportW: innerWidth,
            docOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth
          };
        }""")
        page.screenshot(path=f"{OUT}/d2_{width}_vendortable.png")
        results[width] = {"toggleClicked": clicked, "info": info, "errors": errs}
        page.close(); ctx.close()
    browser.close()

print(json.dumps(results, indent=2))
with open(f"{OUT}/d2_results.json", "w") as f:
    json.dump(results, f, indent=2)
